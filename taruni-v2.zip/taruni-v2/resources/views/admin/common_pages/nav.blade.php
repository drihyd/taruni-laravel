<nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">

      <button type="button" id="sidebarCollapse" class="btn btn-togglebar">
          <i class="fas fa-align-left"></i>
          <!-- <span>Toggle Sidebar</span> -->
      </button>
      <h3 class="mb-0">Dashboard</h3>
      <div class="dropdown pull-right header-user-dropdown" style="display: inline-block;">
      <button class="btn btn-admin dropdown-toggle" type="button" id="userDropMenu" data-toggle="dropdown">
      admin</button>
      <ul class="dropdown-menu" role="menu" aria-labelledby="userDropMenu">
      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Profile</a></li>
      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>