
<?php $__env->startSection('content'); ?>
<div class="paddingleftright pt-2 pb-5" >
          
<?php if(isset($page->id)): ?>
<form id="crudTable" action="<?php echo e(route('pages.update',$page->id)); ?>" method="POST"  enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo e($page->id); ?>">
<?php echo method_field('PUT'); ?>
<?php else: ?>
<form id="crudTable" action="<?php echo e(route('pages.store')); ?>" method="POST"  enctype="multipart/form-data">
<?php endif; ?>  
      <?php echo csrf_field(); ?>
              <div class="row mt-3">
              <div class="col-sm-1">
                <label>Name<span style="color: red;">*</span></label>
                
              </div>
              <div class="col-sm-5 pl-4">
                <input type="text" name="name" class="form-control nameForSlug" required="required" value="<?php echo e(old('name',$page->name??'')); ?>">
              </div>
            </div>
              <div class="row mt-3">
              <div class="col-sm-1">
                <label>Slug<span style="color: red;">*</span></label>
                
              </div>
              <div class="col-sm-5 pl-4">
                <input type="text" name="slug" class="form-control slugForName" required="required" value="<?php echo e(old('slug',$page->slug??'')); ?>">
              </div>
            </div>

            <div class="row mt-3">
              <div class="col-sm-1">
                <label>Description<span style="color: red;">*</span></label>
              </div>
              <div class="col-sm-8 pl-4">
                <textarea id="page_editor" name="description" rows="8" cols="50" class="form-control ckeditor" required="required"><?php echo e(old('description',$page->description??'')); ?></textarea>
                  
              </div>
            </div>
            <div class="row">
               <div class="col-sm-1">
                <label>&nbsp;</label>
              </div>
                <div class="col-sm-3 pl-4">
                  <button type="submit" class="btn btn-outline-success btn-sm mt-3">Save</button>
                      <a href="<?php echo e(url('admin/pages')); ?>" class="btn btn-outline-danger btn-sm mt-3">Back</a>
                      
                 </div> 
             </div> 
        </form> 
      </div>
 <?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
   $("#crudTable").validate({
  rules: {
  name: {
      required: true,
      
    },
     description: {
      required: true,
      
    },
    max_admissions: {
      required: true,
      number:true,
      minlength:1,
      maxlength:100
    },course_fee: {
      required: true,
      number:true,
      minlength:2,
      maxlength:100
    },
    institute_id: {
      required: true
    }
  }
});
 </script> 
 <?php $__env->stopPush(); ?>
 
<?php echo $__env->make('admin.template_v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deepredink/public_html/taruni-v2/resources/views/admin/pages/add_edit_pages.blade.php ENDPATH**/ ?>