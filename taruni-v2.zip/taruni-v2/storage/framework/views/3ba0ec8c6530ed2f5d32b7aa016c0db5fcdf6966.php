
<?php $__env->startSection('content'); ?>
			
            <div class="paddingleftright pt-2 pb-5" >
            	<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>	
    <div class="float-right">
    	<a href="<?php echo e(route('categories.create')); ?>" class="btn btn-brand">+ Add Parent Category</a>
      <a href="<?php echo e(route('pages.create')); ?>" class="btn btn-brand">+ Add Child Category</a>
    </div>
                <!-- <table id="orders-table" class="table customdatatable" style="width:100%"> -->
                <table  class="table customdatatable" style="width:100%">
                  <thead>
                      <tr>
                        <th>Category Name</th>
                        <th>Parent</th>
                        <th>Actions</th>
                      </tr>
                  </thead>
                  <tbody>
                  	 <?php $__currentLoopData = $categories_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($category->parent_id == 0): ?>
                      <tr class="processing odd">
                          <td><a href="#" class="edit mr-2" title="Edit" ><?php echo e(ucwords($category->name)); ?></a></td>
                          <td>  </td>
                          <td width="10%">
            
                          	<a href="#" class="edit mr-2" title="Edit" ><i class="fas fa-pen"></i>
                          	</a>
      
                          </td>
                      </tr>
                      <?php $__currentLoopData = $categories_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentfilter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($parentfilter->parent_id == $category->id): ?>
                      <tr >
                          <td><a href="#" class="edit mr-2" title="Edit" ><?php echo e(ucwords($parentfilter->name)); ?></a></td>
                          <td><?php echo e(ucwords($category->name)); ?>  </td>
                          <td width="10%">
                            <a href="#" class="edit mr-2" title="Edit" ><i class="fas fa-pen"></i>
                            </a>
      
                          </td>
                      </tr>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template_v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deepredink/public_html/taruni-v2/resources/views/admin/categories/categories_list.blade.php ENDPATH**/ ?>