<?php $__env->startSection('title', $pageTitle); ?>
<?php $__env->startSection('content'); ?>
<section>
      <div class="container">	
			<h2 class="smaller margin-top-30"><?php echo e($pageTitle); ?> <small> (<?php echo e($wishlists->count()); ?> Wishlist Found)</small></h2>
			<div class="row">

	



			<?php if($wishlists): ?>
			<?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php
			$price=$product['images'][0]->pprice??0;
			?>

			<?php if($price>0): ?>
			
              <div class="col-sm-3 col-6">                  
                <div class="product-wrapper">
				             
                <a href="<?php echo e(URL('/product/'.$product->pslug)); ?>">
                  <div class="text-center product-img">
                    <img src="<?php echo e(env('BASE_URL').$product->pcode.'_dp.jpg'); ?>" alt="<?php echo e(Str::ucfirst($product->pname)); ?>" class="img-fluid">
					
                  </div>
                  <p class="text-black mt-3"><b>INR <?php echo e($price); ?>/-</b></p>
                  <p class="small"><?php echo e(Str::ucfirst($product->pname)); ?></p>
                  
                </a>
                <div class="cartwish-select">
                    <a href="<?php echo e(URL('/product/'.$product->pslug)); ?>"><i class="fas fa-shopping-cart float-left"></i></a>
                    <a href="<?php echo e(route('wishlist.destroy', Crypt::encryptString($product->wid))); ?>"><i class="fas fa-trash float-right"></i></a>
                </div>           
                </div>		
           
			   </div>
			
			 			   

			  <?php else: ?>
			   <?php endif; ?>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  <?php else: ?>			  
			  <?php endif; ?>



			
			  
        
		 </div>
          
       
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.template_v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deepredink/public_html/taruni-v2/resources/views/frontend/wishlist.blade.php ENDPATH**/ ?>