<?php $__env->startSection('title', 'Under Construction'); ?>
<?php $__env->startSection('content'); ?>
<section>
<div class="container">
    <div class="row>">
        <div class="col-md-12>">
            <h2>Page Under Construction</h2>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.template_v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deepredink/public_html/taruni-v2/vendor/larsjanssen6/underconstruction/src/../resources/views/index.blade.php ENDPATH**/ ?>