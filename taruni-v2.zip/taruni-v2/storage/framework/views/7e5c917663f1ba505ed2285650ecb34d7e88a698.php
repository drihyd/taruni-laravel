<header class="main-header">
      <div class="container">
        <div class="text-center mt-3">
          <a href="<?php echo e(URL('/')); ?>"><img src="<?php echo e(URL::to('images/logo.svg')); ?>" alt="Taruni Logo" class="img-fluid nav-logo"></a>
        </div>
        <div class="cart-wrapper">
            <!-- <div class="search-container">
              <form action="/search" method="get">
                <input class="search" id="searchleft" type="search" name="q" placeholder="Search">
                <label class="button searchbutton" for="searchleft"><span class="mglass">&#9906;</span></label>
              </form>
            </div> -->
              <a href="<?php echo e(URL('/search')); ?>" class="mr-3"><img src="<?php echo e(URL::to('images/search.svg')); ?>" alt="search" class="img-fluid"></a>
              <a href="<?php echo e(URL('/cart')); ?>" class="mr-3 pos-relative"><img src="<?php echo e(URL::to('images/cart.svg')); ?>" alt="Cart" class="img-fluid"><span class="item-count" id="nav_no_cart_items">
		  <?php if(isset($cartCount)): ?>
				<?php echo e($cartCount??''); ?>

				<?php else: ?>
				<?php endif; ?>
			  </span></a>
				
		
			  
              <a href="<?php echo e(URL('/wishlist')); ?>" class="pos-relative"><img src="<?php echo e(URL::to('images/wishlist.svg')); ?>" alt="wishlist" class="img-fluid"><span class="item-count" id="nav_no_cart_items">0</span></a>
        </div>
		
		<?php
		use App\Models\Categories;
		$Categories=Categories::where("parent_id",'0')->wherenotin("slug",['accessories','kids-wear','bags','bangles','offers','discounts','mix-and-match'])->orderBy('name', 'ASC')->get();
		?>
		
		
         <nav class="navbar navbar-expand-lg navbar-light p-0">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
				
					<li class="nav-item dropdown active">
						<a class="nav-link link-about dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						Women
						</a>
							<div class="dropdown-menu navitem-submenu" aria-labelledby="navbarDropdownMenuLink">							
								<?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a class="dropdown-item" href="<?php echo e(URL('/category/'.$category->slug)); ?>"><?php echo e($category->name); ?></a>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
					</li>
					
					
					<li class="nav-item">
                    <a class="nav-link link-about " href="<?php echo e(URL('/category/kids-wear')); ?>" id="navbarDropdownMenuLink"  aria-haspopup="true" aria-expanded="false">
                    Kids
                    </a>
					</li>
            
                <li class="nav-item dropdown">
                    <a class="nav-link link-about dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Accessories
                    </a>
                    <div class="dropdown-menu navitem-submenu" aria-labelledby="navbarDropdownMenuLink">
                      <a class="dropdown-item" href="<?php echo e(URL('/category/accessories')); ?>"">Jewellery</a>
                      <a class="dropdown-item" href="<?php echo e(URL('/category/bags')); ?>"">Bags</a>
                      <a class="dropdown-item" href="<?php echo e(URL('/category/bangles')); ?>"">Bangles</a>
					  

                    </div>
                </li>
				
					  
				  
                  <div class="account-wrapper">
                    <li class="nav-item">
						<?php if(Auth::check()): ?> :
                    <a class="nav-link" href="<?php echo e(route('register.logout')); ?>">Logout</a>
					<?php else: ?>:
					 <a class="nav-link" href="<?php echo e(URL('/myaccount')); ?>">Sign in</a>
					 <?php endif; ?>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(URL('/help')); ?>">Help</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(URL('/contactus')); ?>">Contact Us</a>
                  </li>
                  </div>
                </ul>
              </div>
      </nav>
      </div>
    </header><?php /**PATH C:\xampp\htdocs\taruni-v2\resources\views/frontend/common_pages/nav.blade.php ENDPATH**/ ?>