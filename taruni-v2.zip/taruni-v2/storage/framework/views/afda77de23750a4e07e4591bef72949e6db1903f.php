 <section class="bg-footer footer-sec pb-3 pt-4">
      <div class="container pt-2">
        <div class="row">
          <div class="col-sm-6">
            <div class="wrapper mb-4">
              <h4 class="text-dark">Categories</h4>
              <div class="row">
                  <div class="col-sm-6">
                      
                      <p><a href="<?php echo e(URL('/category/anarkali')); ?>">Anarkalir</a></p>
                      <p><a href="<?php echo e(URL('/category/dupattas')); ?>">Dupattas</a></p>
                      <p><a href="<?php echo e(URL('/category/juttis')); ?>">Juttis</a></p>
                      <p><a href="<?php echo e(URL('/category/kurtis')); ?>">kurtis</a></p>
                      <p><a href="<?php echo e(URL('/category/leggings')); ?>">Leggings</a></p>
                  </div>
                  <div class="col-sm-6">
                      <p><a href="<?php echo e(URL('/category/lehengas')); ?>">Lehengas</a></p>
                      <p><a href="<?php echo e(URL('/category/palazzos-pants')); ?>">Palazzos &amp; Pants</a></p>
                      <p><a href="<?php echo e(URL('/category/kurties')); ?>">Kurtis</a></p>
                      <p><a href="<?php echo e(URL('/category/ghararas')); ?>">Shararas/Ghararas</a></p>
                      <p><a href="<?php echo e(URL('/category/kids-wear')); ?>">Kids</a></p>
                  </div>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
            <div class="wrapper mb-4">
              <h4 class="text-dark">Collections</h4>
              <p><a href="<?php echo e(URL('/category/summer-wear')); ?>">Summer Wear</a></p>
              <p><a href="<?php echo e(URL('/category/accessories')); ?>">Jewellery</a></p>
              <p><a href="<?php echo e(URL('/category/bags')); ?>">Bags</a></p>
              <p><a href="<?php echo e(URL('/category/bangles')); ?>">Bangles</a></p>
              <p><a href="<?php echo e(URL('/category/sandals')); ?>">Sandals</a></p>
            </div>
          </div>
          <!--<div class="col-sm-3">-->
          <!--  <div class="wrapper mb-4">-->
          <!--    <h4 class="text-dark">Lookbooks</h4>-->
          <!--    <p><a href="<?php echo e(URL('/category/lookbooks')); ?>">Lookbooks</a></p>-->
          <!--  </div>-->
          <!--</div>-->
          <div class="col-sm-3">
            <div class="wrapper mb-4">
              <h4 class="text-dark">Help</h4>
              <p><a href="<?php echo e(URL('/blog')); ?>">Blog</a></p>
              <p><a href="<?php echo e(URL('/products/locations')); ?>">Locations</a></p>
            </div>
          </div>
        </div>
		
		
	<div class="row">
	    <div class="col-sm-4">
	        <div class="social-links">
              <p>
                <a href="https://www.facebook.com/taruni.in" class="facebook-link" target="_blank"><i class="fab fa-facebook-square"></i></a>
                <a href="https://www.instagram.com/taruni.in/" class="instagram-link" target="_blank"><i class="fab fa-instagram-square"></i></a>
                <a href="https://twitter.com/TaruniOfficial" class="twitter-link" target="_blank"><i class="fab fa-twitter-square"></i></a>
                <a href="https://in.pinterest.com/taruniOfficial/" class="pinterest-link" target="_blank"><i class="fab fa-pinterest-square"></i></a>
                <a href="https://www.youtube.com/channel/UCecFAgCOVpGA5g0ZnlJvvvQ" class="youtube-link" target="_blank"><i class="fab fa-youtube"></i></a> 
              </p>
            </div>
	    </div>
	    <div class="col-sm-8">
	        <div class="terms-links">
              <p>
        		<a href="<?php echo e(URL('/terms_conditions')); ?>">Terms &amp; Conditions</a> | 
        		<a href="<?php echo e(URL('/disclaimer')); ?>">Disclaimer</a> |
        		<a href="<?php echo e(URL('/privany_policy')); ?>">Privacy policy</a> |
        		<a href="<?php echo e(URL('/canellation_and_refund_policy')); ?>">Cancellation and Refund Policy</a> |
        		<a href="<?php echo e(URL('/shipping_and_delivery')); ?>">Shipping and Delivery</a> |
        		<a href="<?php echo e(URL('/how_it_works')); ?>">How it works</a> |
        		<a href="<?php echo e(URL('/faqs')); ?>">FAQs</a>
              </p>
            </div>
	    </div>
	</div>	

		
		
			
        
		
        
		
		
		
		
		
		
		

		
		
		
        <div>
          <p class="small">&COPY; <?php echo e(env('APP_COPYRIHGT')); ?></p>
        </div>
      </div>
    </section><?php /**PATH /home/deepredink/public_html/taruni-v2/resources/views/frontend/common_pages/footer.blade.php ENDPATH**/ ?>