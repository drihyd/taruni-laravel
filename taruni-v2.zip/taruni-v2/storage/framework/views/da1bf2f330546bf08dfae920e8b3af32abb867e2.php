<p style="font-size: 12px;						
font-weight: 400;
color: #6f6f72;">
<?php echo e(Auth::user()->firstname??''); ?> <?php echo e(Auth::user()->lastname??''); ?><br>
<?php echo e(Auth::user()->address??''); ?><br>
<?php echo e(Auth::user()->city??''); ?> - <?php echo e(Auth::user()->state??''); ?><br>

Pincode-<?php echo e(Auth::user()->pincode??''); ?>

<br>Phone: +91-<?php echo e(Auth::user()->phone??''); ?>

<br>Email: <?php echo e(Auth::user()->email??''); ?>

</p>  <?php /**PATH /home/deepredink/public_html/taruni-v2/resources/views/frontend/cart_shipped.blade.php ENDPATH**/ ?>