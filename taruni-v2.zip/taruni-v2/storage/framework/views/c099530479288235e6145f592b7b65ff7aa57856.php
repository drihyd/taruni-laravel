<?php
use App\Models\Categories;
$Categories=Categories::where("parent_id",'0')->orderBy('name', 'ASC')->get();
dd($Categories);
?>	
<?php /**PATH C:\xampp\htdocs\taruni-v2\resources\views/masters/categories.blade.php ENDPATH**/ ?>