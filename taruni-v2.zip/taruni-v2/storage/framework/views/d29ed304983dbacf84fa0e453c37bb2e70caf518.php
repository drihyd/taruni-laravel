
<?php $__env->startSection('content'); ?>
			
            <div class="paddingleftright pt-2 pb-5" >
            	<?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>	
    <div class="float-right">
    	<a href="<?php echo e(route('pages.create')); ?>" class="btn btn-brand">+ Add</a>
    </div>
                <table id="orders-table" class="table customdatatable" style="width:100%">
                  <thead>
                      <tr>
                      	<th>S.No.</th>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Description</th>
                        <th>Actions</th>
                      </tr>
                  </thead>
                  <tbody>
                  	 <?php $__currentLoopData = $pages_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr >
                      	<td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($page->name); ?></td>
                          <td><?php echo e($page->slug); ?></td>
                          <td><?php echo Str::limit(html_entity_decode($page->description), 150); ?></td>

                          <td width="10%">
                          	<form action="<?php echo e(route('pages.destroy',$page->id)); ?>" method="POST">
                          	<a  href="<?php echo e(route('pages.show',$page->id)); ?>"><i class="fas fa-eye"></i></a>&nbsp;
                          	<a href="<?php echo e(route('pages.edit',$page->id)); ?>" class="edit mr-2" title="Edit" ><i class="fas fa-pen"></i>
                          	</a>
                          	
                          	<button type="submit"  class="fas fa-trash-alt btn btn-none" onclick="return confirm('Are you sure to delete this?')" style="box-shadow: none; outline: none; background: unset; cursor: pointer; padding: 0;">
                          	</button>
                          	<?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
      
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template_v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deepredink/public_html/taruni-v2/resources/views/admin/pages/pages_list.blade.php ENDPATH**/ ?>